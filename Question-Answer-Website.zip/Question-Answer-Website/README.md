# QUESTION-ANSWER-WEBSITE-Using-PYTHON-DJANGO

Its a Question & Answer Website developed using Python Django.

Contains following features : 

- Can login / Register.
- You can ask question randomly 
- You can Answer all Questions.
-  You can follow any user.
- You can  Like any Question or Answer.
- Can see other Users profile.
- Will receive Notifications.
- Can update your profile. 

username: Ramya
password: test@123

username:Karthik
password: 123@test

username:Layashree
paassword:laya@123
gmail:laya@gmail.com

username:Joe
paassword:joe@123
gmail:joe@gmail.com

username:Rachel Bloom
paassword:bloom@123
email:bloom@gmail.com

username:Stella Mathew
paassword:stella@123
email:stella@gmail.com

username:Chandler
paassword:bing@123
email:bing@gmail.com

username:Ben Geller
paassword:geller@123
email:geller@gmail.com